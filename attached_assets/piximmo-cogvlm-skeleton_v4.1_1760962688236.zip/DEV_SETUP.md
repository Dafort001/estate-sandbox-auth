# piximmo-cogvlm-api – Developer Setup Guide

## 🚀 Quick Start
```bash
npm install
npm run dev
```

Server läuft dann unter:
➡️ http://localhost:3000

## ⚙️ Environment Variables (.env.example)
```bash
PORT=3000
NODE_ENV=development
STORAGE_DRIVER=fs
STORAGE_ROOT=./storage
R2_BUCKET=piximmo
R2_ENDPOINT=https://<accountid>.r2.cloudflarestorage.com
R2_ACCESS_KEY_ID=<your-access-key-id>
R2_SECRET_ACCESS_KEY=<your-secret-access-key>
COGVLM_API_URL=https://api.modal.com/cogvlm2
COGVLM_API_KEY=<your-modal-or-replicate-key>
PIXIMMO_PROJECT=piximmo-caption-pipeline
```

## 🧠 API Endpoints
| Route | Methode | Beschreibung |
|--------|----------|---------------|
| /api/callback/cogvlm | POST | CogVLM-Ergebnisse speichern |
| /api/expose/build | POST | Baut das Exposé |
| /api/shoots/:shoot_id/index.json | GET | Status/Manifest |
| /api/export/:shoot_id?type=txt|json|all | GET | ZIP-Export |

## 🧪 Beispiel-Requests (cURL)
```bash
curl -X POST http://localhost:3000/api/callback/cogvlm -H "Content-Type: application/json" -d '{"shoot_id": "2025-10-20_AB123","filename": "2025-10-20-AB123_wohnzimmer_01_v1.jpg","model_text": "ROOM TYPE & OVERVIEW:\nBright living area...","prompt_key": "wohnzimmer"}'
curl -X POST http://localhost:3000/api/expose/build -H "Content-Type: application/json" -d '{"shoot_id": "2025-10-20_AB123"}'
curl http://localhost:3000/api/shoots/2025-10-20_AB123/index.json
curl -L http://localhost:3000/api/export/2025-10-20_AB123?type=txt -o captions.zip
```

## 🗄️ Storage Drivers
STORAGE_DRIVER=fs → lokaler Speicher
STORAGE_DRIVER=r2 → Cloudflare R2

## 📦 Exportstruktur
shoots/<shoot_id>/
├── captions/
│   ├── txt/
│   └── json/
├── expose/
│   ├── paragraphs/
│   └── expose_full.md
└── index.json

## 🧩 Pipelinefluss
1. Worker Upload → Modal (CogVLM)
2. Callback → API speichert + parsed
3. Storage (R2 oder lokal)
4. Exposé-Build
5. Download (ZIP)
6. Manifest-Status über Dashboard
