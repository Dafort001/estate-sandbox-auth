# piximmo-cogvlm-api (skeleton)

**Created:** 2025-10-20

Minimal Hono + TypeScript API to use the pix.immo CogVLM prompt bundle.

## Quick start (Replit)
1. Copy the folder contents into your Replit project root.
2. Place the bundled prompts at `config/cogvlm_prompts_bundle_v1.json` (already included).
3. Set env:
   - `COGVLM_API_URL`
   - `COGVLM_API_KEY`
4. Run: `npm i` then `npm run dev`

### Endpoints
- `POST /api/caption` → returns normalized sections.
- `POST /api/write` → returns Alt-Text or Exposé paragraph.

See `src/routes/caption.ts` for details.


## New endpoints
- `POST /api/callback/cogvlm` – nimmt CogVLM-Ergebnisse an, erzeugt Artefakte (.json/.txt), aktualisiert Manifest
- `POST /api/expose/build` – erzeugt `expose_full.md` aus allen Raum-Sections
- `GET  /api/shoots/:shoot_id/index.json` – gibt Manifest zurück
- `GET  /api/export/:shoot_id?type=txt|json|all` – exportiert Artefakte als NDJSON-Stream (einfacher ZIP-Ersatz)

## Storage
- Lokal simuliert über `STORAGE_ROOT` (Default `./storage`). In Produktion gegen R2 austauschen.


## Silent workflow
- Es werden **keine** Benachrichtigungen (Mail/SMS) versendet.
- Der Fortschritt ist ausschließlich über das `index.json`-Manifest und die Kundenlogin-UI sichtbar.


## Storage drivers
- `STORAGE_DRIVER=fs` (default) → nutzt lokalen Ordner `./storage`
- `STORAGE_DRIVER=r2` → nutzt Cloudflare R2 (S3)

### R2 Env Variablen
- `R2_BUCKET`
- `R2_ENDPOINT` (z. B. https://<accountid>.r2.cloudflarestorage.com)
- `R2_ACCESS_KEY_ID`
- `R2_SECRET_ACCESS_KEY`

### Lokal
- `STORAGE_ROOT` (Standard `./storage`)

## Export
- `GET /api/export/:shoot_id?type=txt|json|all` liefert **ZIP** via `archiver`.
