import { Hono } from 'hono'
import { captionRouter } from './routes/caption'
import { postprocRouter } from './routes/postproc'
import { exportRouter } from './routes/export'

const app = new Hono()

app.route('/api', captionRouter)
app.route('/api', postprocRouter)
app.route('/api', exportRouter)

export default app

// For local dev (e.g., with tsx):
if (typeof Bun === 'undefined') {
  const port = Number(process.env.PORT || 3000)
  // @ts-ignore - fetch-like server in Hono runtime adapters; for Node use hono/serve if needed
  const server = app.fire?.() || null
  console.log(`pix.immo CogVLM API running on http://localhost:${port}`)
}
