import { fetch } from 'undici'

export type CogVLMResponse = {
  text: string // raw model text (sections)
}

export async function callCogVLM(imageUrl: string, promptText: string): Promise<CogVLMResponse> {
  const url = process.env.COGVLM_API_URL
  const key = process.env.COGVLM_API_KEY
  if (!url || !key) {
    console.warn('COGVLM_API_URL / COGVLM_API_KEY not configured, returning stub response.')
    return {
      text: [
        'ROOM TYPE & OVERVIEW:',
        'Neutral overview text.',
        'ARCHITECTURAL FEATURES:',
        '- windows',
        '- doors',
        'LIGHT & ORIENTATION:',
        'bright, likely south-facing',
        'MATERIALS & SURFACES:',
        '- wood floor',
        '- white walls',
        'STYLE & IMPRESSION:',
        'contemporary, well-kept',
        'LIMITATIONS/ASSUMPTIONS:',
        'no people or furniture described'
      ].join('\n')
    }
  }

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${key}`
    },
    body: JSON.stringify({
      prompt: promptText,
      image_url: imageUrl
    })
  })
  if (!res.ok) {
    const body = await res.text()
    throw new Error(`CogVLM error ${res.status}: ${body}`)
  }
  const data = await res.json()
  // Adjust depending on provider contract
  return { text: data.text ?? String(data) }
}
