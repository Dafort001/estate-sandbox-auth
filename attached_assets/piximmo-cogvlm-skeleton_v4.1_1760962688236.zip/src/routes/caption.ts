import { Hono } from 'hono'
import fs from 'node:fs'
import path from 'node:path'
import type { PromptBundle } from '../lib/roomtype'
import { extractRoomTypeFromFilename, getPromptForRoomType } from '../lib/roomtype'
import { callCogVLM } from '../services/cogvlm'
import { parseModelTextToSections } from '../lib/normalize'
import { altTextFromSections, exposeParagraphFromSections } from '../lib/writers'

export const captionRouter = new Hono()

// Load bundle on module init
const bundlePath = path.resolve('config/cogvlm_prompts_bundle_v1.json')
const bundle: PromptBundle = JSON.parse(fs.readFileSync(bundlePath, 'utf-8'))

captionRouter.post('/caption', async (c) => {
  const body = await c.req.json() as {
    filename: string
    room_type?: string
    image_url: string
    lang?: 'de'|'en'
  }

  const lang = body.lang ?? 'de'
  const filename = body.filename
  const roomType = (body.room_type ?? extractRoomTypeFromFilename(filename)).toLowerCase()
  const promptEntry = getPromptForRoomType(bundle, roomType)

  const model = await callCogVLM(body.image_url, promptEntry.text)
  const sections = parseModelTextToSections(model.text, bundle.prompts.section_schema)

  const normalized = {
    room_type: roomType,
    sections,
    raw: {
      model_text: model.text,
      prompt_used: roomType in bundle.prompts.prompts ? roomType : bundle.prompts.default_prompt_key,
      source_file: promptEntry.source_file
    }
  }

  return c.json(normalized)
})

captionRouter.post('/write', async (c) => {
  const body = await c.req.json() as {
    sections: ReturnType<typeof parseModelTextToSections>
    type: 'alt'|'expose'
    lang?: 'de'|'en'
  }
  const lang = body.lang ?? 'de'
  const s = body.sections
  const text = body.type === 'alt'
    ? altTextFromSections(s, lang)
    : exposeParagraphFromSections(s, lang)

  return c.json({ text, type: body.type, lang })
})
