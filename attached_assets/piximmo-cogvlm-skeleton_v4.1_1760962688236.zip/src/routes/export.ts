import { Hono } from 'hono'
import fs from 'node:fs'
import path from 'node:path'
import archiver from 'archiver'
import { Storage } from '../lib/storage_index'

export const exportRouter = new Hono()

exportRouter.get('/export/:shoot_id', async (c) => {
  const shootId = c.req.param('shoot_id')
  const type = (c.req.query('type') || 'txt').toLowerCase() // txt|json|all

  const prefix = type === 'txt'
    ? `shoots/${shootId}/captions/txt`
    : type === 'json'
      ? `shoots/${shootId}/captions/json`
      : `shoots/${shootId}`

  const list = await Storage.listPrefix(prefix)
  if (!list.length) return c.text('No files', 404)

  // Create a zip file on local FS (temp) and stream back
  const tmpDir = Storage.fsPath('tmp')
  fs.mkdirSync(tmpDir, { recursive: true })
  const zipPath = path.join(tmpDir, `${shootId}_${type}.zip`)

  await new Promise<void>(async (resolve, reject) => {
    const output = fs.createWriteStream(zipPath)
    const archive = archiver('zip', { zlib: { level: 9 }})

    output.on('close', () => resolve())
    archive.on('error', (err) => reject(err))

    archive.pipe(output)

    for (const key of list) {
      const buf = await Storage.getObject(key)
      if (!buf) continue
      const rel = key.replace(/^shoots\//, '')
      archive.append(buf, { name: rel })
    }

    archive.finalize()
  })

  const stream = fs.createReadStream(zipPath)
  c.header('Content-Type', 'application/zip')
  c.header('Content-Disposition', `attachment; filename="${shootId}_${type}.zip"`)
  // @ts-ignore Hono Response from Node stream
  return new Response(stream as any)
})
