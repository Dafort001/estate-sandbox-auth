import { Hono } from 'hono'
import { parseModelTextToSections } from '../lib/normalize'
import { altTextFromSections, exposeParagraphFromSections } from '../lib/writers'
import { Storage } from '../lib/storage_index'
import { bumpCounters, loadManifest } from '../lib/manifest'
import { buildExposeMarkdown } from '../lib/expose_builder'

export const postprocRouter = new Hono()

postprocRouter.post('/callback/cogvlm', async (c) => {
  const body = await c.req.json() as {
    shoot_id: string
    filename: string
    image_url?: string
    model_text: string
    prompt_key: string
    latency_ms?: number
  }

  // 1) Parse to sections (EN schema assumed)
  const schema = [
    'ROOM TYPE & OVERVIEW',
    'ARCHITECTURAL FEATURES',
    'LIGHT & ORIENTATION',
    'MATERIALS & SURFACES',
    'STYLE & IMPRESSION',
    'LIMITATIONS/ASSUMPTIONS'
  ]
  const sections = parseModelTextToSections(body.model_text, schema)

  // 2) Writers (DE standard)
  const alt = altTextFromSections(sections, 'de')
  const exp = exposeParagraphFromSections(sections, 'de')

  // 3) Persist artifacts
  const shootId = body.shoot_id
  const base = body.filename.replace(/\.(jpg|jpeg|png)$/i, '')
  await Storage.writeJSON(`shoots/${shootId}/captions/json/${base}.json`, {
    filename: body.filename,
    room_type: extractRoomType(body.filename),
    sections,
    alt_text_de: alt,
    expose_de: exp,
    prompt_key: body.prompt_key,
    model: 'CogVLM2',
    pipeline_version: 'piximmo_caption_v1',
    ts: new Date().toISOString()
  }, { ensureDir: true })
  await Storage.writeText(`shoots/${shootId}/captions/txt/${base}.txt`, alt, { ensureDir: true })
  await Storage.writeText(`shoots/${shootId}/expose/paragraphs/${base}.txt`, exp, { ensureDir: true })

  // 4) Manifest counters
  const m = bumpCounters(shootId, { captioned: 1 })

  return c.json({ ok: true, manifest: m })
})

// Helper to extract room_type from filename
function extractRoomType(name: string) {
  const m = name.toLowerCase().match(/_(\w+)_/)
  return m?.[1] ?? 'undefined_space'
}

postprocRouter.post('/expose/build', async (c) => {
  const body = await c.req.json() as { shoot_id: string }
  const md = buildExposeMarkdown(body.shoot_id)
  return c.text(md)
})

postprocRouter.get('/shoots/:shoot_id/index.json', async (c) => {
  const shootId = c.req.param('shoot_id')
  const m = loadManifest(shootId)
  return c.json(m)
})
