import fs from 'node:fs'
import path from 'node:path'

export type WriteOptions = { ensureDir?: boolean }

const ROOT = process.env.STORAGE_ROOT || 'storage' // simulate R2 in local FS

export function r2Path(p: string) {
  return path.resolve(ROOT, p.replace(/^\/+/, ''))
}

export function ensureDirSync(dir: string) {
  const full = r2Path(dir)
  fs.mkdirSync(full, { recursive: true })
  return full
}

export function writeText(p: string, content: string, opt: WriteOptions = {}) {
  const full = r2Path(p)
  if (opt.ensureDir) fs.mkdirSync(path.dirname(full), { recursive: true })
  fs.writeFileSync(full, content, 'utf-8')
  return full
}

export function writeJSON(p: string, obj: any, opt: WriteOptions = {}) {
  return writeText(p, JSON.stringify(obj, null, 2), opt)
}

export function readJSON<T=any>(p: string): T | null {
  const full = r2Path(p)
  if (!fs.existsSync(full)) return null
  return JSON.parse(fs.readFileSync(full, 'utf-8')) as T
}

export function appendLog(p: string, line: string, opt: WriteOptions = {}) {
  const full = r2Path(p)
  if (opt.ensureDir) fs.mkdirSync(path.dirname(full), { recursive: true })
  fs.appendFileSync(full, line + '\n', 'utf-8')
  return full
}

export function exists(p: string) {
  return fs.existsSync(r2Path(p))
}
