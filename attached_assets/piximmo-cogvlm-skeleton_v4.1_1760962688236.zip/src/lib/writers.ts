import type { NormalizedSections } from './normalize'

export function altTextFromSections(s: NormalizedSections, lang: 'de'|'en' = 'de'): string {
  if (lang === 'en') {
    return [
      s.overview,
      s.light_orientation ? `Light: ${s.light_orientation}.` : ''
    ].filter(Boolean).join(' ')
  }
  // German
  const parts = [
    s.overview,
    s.light_orientation ? `Licht: ${s.light_orientation}.` : ''
  ].filter(Boolean)
  // limit to ~2 sentences
  return parts.join(' ')
}

export function exposeParagraphFromSections(s: NormalizedSections, lang: 'de'|'en' = 'de'): string {
  if (lang === 'en') {
    const bits = [
      s.overview,
      s.features.length ? `Notable features: ${s.features.slice(0,4).join(', ')}.` : '',
      s.materials.length ? `Materials: ${s.materials.slice(0,4).join(', ')}.` : '',
      s.style_impression
    ].filter(Boolean)
    return bits.join(' ')
  }
  // German
  const bits = [
    s.overview,
    s.features.length ? `Merkmale: ${s.features.slice(0,4).join(', ')}.` : '',
    s.materials.length ? `Materialien: ${s.materials.slice(0,4).join(', ')}.` : '',
    s.style_impression
  ].filter(Boolean)
  return bits.join(' ')
}
