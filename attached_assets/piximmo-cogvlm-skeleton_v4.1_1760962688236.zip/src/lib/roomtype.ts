export type PromptBundle = {
  bundle_version: string
  created: string
  project: string
  notes?: string
  prompts: {
    version: string
    created: string
    language: string
    style: string
    output_format: 'sections' | 'json' | 'text'
    section_schema: string[]
    default_prompt_key: string
    prompts: Record<string, {
      display_name: string
      category: 'interior'|'exterior'|'utility'
      source_file: string
      text: string
    }>
  }
  mapping: {
    version: string
    description: string
    created: string
    default_prompt: string
    mapping: Record<string,string>
  }
}

export function extractRoomTypeFromFilename(name: string): string {
  // expecting pattern with _{room_type}_ inside the filename
  const m = name.toLowerCase().match(/_(\w+)_/)
  return m?.[1] ?? 'undefined_space'
}

export function getPromptForRoomType(bundle: PromptBundle, roomType: string) {
  const key = roomType.toLowerCase()
  const p = bundle.prompts.prompts[key]
  if (p) return p
  return bundle.prompts.prompts[bundle.prompts.default_prompt_key]
}
