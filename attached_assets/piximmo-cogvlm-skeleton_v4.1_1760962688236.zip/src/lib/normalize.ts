export type NormalizedSections = {
  overview: string
  features: string[]
  light_orientation: string
  materials: string[]
  style_impression: string
  limitations: string
}

const SECTION_MAP: Record<string, keyof NormalizedSections> = {
  'ROOM TYPE & OVERVIEW': 'overview',
  'ARCHITECTURAL FEATURES': 'features',
  'LIGHT & ORIENTATION': 'light_orientation',
  'MATERIALS & SURFACES': 'materials',
  'STYLE & IMPRESSION': 'style_impression',
  'LIMITATIONS/ASSUMPTIONS': 'limitations'
}

export function parseModelTextToSections(modelText: string, schema: string[]): NormalizedSections {
  // naive parser: split by headings present in schema
  const out: any = {
    overview: '',
    features: [] as string[],
    light_orientation: '',
    materials: [] as string[],
    style_impression: '',
    limitations: ''
  }

  // Create regex to find each section title
  const indices: {title: string, index: number}[] = []
  for (const title of schema) {
    const idx = modelText.indexOf(title)
    if (idx >= 0) indices.push({ title, index: idx })
  }
  indices.sort((a,b) => a.index - b.index)

  for (let i = 0; i < indices.length; i++) {
    const { title, index } = indices[i]
    const end = i < indices.length - 1 ? indices[i+1].index : modelText.length
    const body = modelText.slice(index + title.length).trim().replace(/^[:\s-]+/, '')
    const segment = body.slice(0, end - (index + title.length)).trim()
    const key = SECTION_MAP[title]
    if (!key) continue

    if (key === 'features' || key === 'materials') {
      const arr = segment.split(/\n|\r|\u2022|\-/).map(s => s.trim()).filter(Boolean)
      out[key] = arr
    } else {
      out[key] = segment
    }
  }

  return out as NormalizedSections
}
