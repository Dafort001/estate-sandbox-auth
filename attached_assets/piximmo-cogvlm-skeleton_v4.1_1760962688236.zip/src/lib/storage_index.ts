import { writeJSON as fsWriteJSON, writeText as fsWriteText, readJSON as fsReadJSON, ensureDirSync as fsEnsure, fsPath as fsPathUtil, exists as fsExists, listPrefix as fsList, getObject as fsGet } from './storage_fs'
import { r2WriteText, r2WriteJSON, r2GetJSON, r2Exists, r2ListPrefix, r2GetObject } from './storage_r2'

const DRIVER = (process.env.STORAGE_DRIVER || 'fs').toLowerCase() // 'fs' or 'r2'

export const Storage = {
  // write
  writeText: async (p: string, content: string, opt: { ensureDir?: boolean } = {}) => {
    if (DRIVER === 'r2') return r2WriteText(p, content)
    if (opt.ensureDir) fsEnsure(p.split('/').slice(0,-1).join('/'))
    return fsWriteText(p, content, opt)
  },
  writeJSON: async (p: string, obj: any, opt: { ensureDir?: boolean } = {}) => {
    if (DRIVER === 'r2') return r2WriteJSON(p, obj)
    if (opt.ensureDir) fsEnsure(p.split('/').slice(0,-1).join('/'))
    return fsWriteJSON(p, obj, opt)
  },

  // read
  readJSON: async <T=any>(p: string): Promise<T|null> => {
    if (DRIVER === 'r2') return r2GetJSON<T>(p)
    return fsReadJSON<T>(p)
  },

  // exists
  exists: async (p: string): Promise<boolean> => {
    if (DRIVER === 'r2') return r2Exists(p)
    return fsExists(p)
  },

  // list
  listPrefix: async (prefix: string): Promise<string[]> => {
    if (DRIVER === 'r2') return r2ListPrefix(prefix)
    return fsList(prefix)
  },

  // get object as Buffer
  getObject: async (p: string): Promise<Buffer|null> => {
    if (DRIVER === 'r2') return r2GetObject(p)
    return fsGet(p)
  },

  // helper for fs paths (for local dev)
  fsPath: (p: string) => fsPathUtil(p)
}
