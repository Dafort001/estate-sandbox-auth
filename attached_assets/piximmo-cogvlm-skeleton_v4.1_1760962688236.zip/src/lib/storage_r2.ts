import { S3Client, PutObjectCommand, GetObjectCommand, HeadObjectCommand, ListObjectsV2Command } from '@aws-sdk/client-s3'
import { Readable } from 'node:stream'

const R2_BUCKET = process.env.R2_BUCKET as string
const R2_ENDPOINT = process.env.R2_ENDPOINT as string // e.g. https://<accountid>.r2.cloudflarestorage.com
const R2_ACCESS_KEY_ID = process.env.R2_ACCESS_KEY_ID as string
const R2_SECRET_ACCESS_KEY = process.env.R2_SECRET_ACCESS_KEY as string

if (!R2_BUCKET || !R2_ENDPOINT || !R2_ACCESS_KEY_ID || !R2_SECRET_ACCESS_KEY) {
  console.warn('[storage_r2] Missing R2 env – storage driver will fail if selected.')
}

const s3 = new S3Client({
  region: 'auto',
  endpoint: R2_ENDPOINT,
  credentials: {
    accessKeyId: R2_ACCESS_KEY_ID || '',
    secretAccessKey: R2_SECRET_ACCESS_KEY || ''
  },
  forcePathStyle: true
})

function keyFromPath(p: string) {
  return p.replace(/^\/+/, '')
}

export async function r2WriteText(p: string, content: string) {
  const Key = keyFromPath(p)
  await s3.send(new PutObjectCommand({
    Bucket: R2_BUCKET,
    Key,
    Body: Buffer.from(content, 'utf-8'),
    ContentType: 'text/plain; charset=utf-8'
  }))
  return Key
}

export async function r2WriteJSON(p: string, obj: any) {
  const Key = keyFromPath(p)
  const Body = Buffer.from(JSON.stringify(obj, null, 2), 'utf-8')
  await s3.send(new PutObjectCommand({
    Bucket: R2_BUCKET,
    Key,
    Body,
    ContentType: 'application/json; charset=utf-8'
  }))
  return Key
}

export async function r2GetJSON<T=any>(p: string): Promise<T|null> {
  const Key = keyFromPath(p)
  try {
    const res = await s3.send(new GetObjectCommand({ Bucket: R2_BUCKET, Key }))
    const stream = res.Body as Readable
    const chunks: Buffer[] = []
    for await (const chunk of stream) chunks.push(Buffer.from(chunk))
    const buf = Buffer.concat(chunks)
    return JSON.parse(buf.toString('utf-8')) as T
  } catch {
    return null
  }
}

export async function r2Exists(p: string): Promise<boolean> {
  const Key = keyFromPath(p)
  try {
    await s3.send(new HeadObjectCommand({ Bucket: R2_BUCKET, Key }))
    return true
  } catch {
    return false
  }
}

export async function r2ListPrefix(prefix: string): Promise<string[]> {
  const Prefix = keyFromPath(prefix).replace(/\/+$/, '') + '/'
  let ContinuationToken: string|undefined = undefined
  const out: string[] = []
  do {
    const res = await s3.send(new ListObjectsV2Command({
      Bucket: R2_BUCKET,
      Prefix,
      ContinuationToken
    }))
    ContinuationToken = (res.IsTruncated && res.NextContinuationToken) ? res.NextContinuationToken : undefined
    for (const o of res.Contents || []) {
      if (o.Key) out.push(o.Key)
    }
  } while (ContinuationToken)
  return out
}

export async function r2GetObject(p: string): Promise<Buffer|null> {
  const Key = keyFromPath(p)
  try {
    const res = await s3.send(new GetObjectCommand({ Bucket: R2_BUCKET, Key }))
    const stream = res.Body as Readable
    const chunks: Buffer[] = []
    for await (const chunk of stream) chunks.push(Buffer.from(chunk))
    return Buffer.concat(chunks)
  } catch {
    return null
  }
}
