import { readJSON, writeJSON, ensureDirSync } from './storage'

export type Manifest = {
  shoot_id: string
  shoot_code?: string
  status: { captioned: number, total: number, errors: number, last_update: string }
  versions: { filename_format: string, caption_pipeline: string }
  links?: Record<string,string>
}

export function loadManifest(shootId: string): Manifest {
  const p = `shoots/${shootId}/index.json`
  const m = readJSON<Manifest>(p)
  if (m) return m
  const now = new Date().toISOString()
  const fresh: Manifest = {
    shoot_id: shootId,
    status: { captioned: 0, total: 0, errors: 0, last_update: now },
    versions: { filename_format: 'v3.1', caption_pipeline: 'piximmo_caption_v1' }
  }
  ensureDirSync(`shoots/${shootId}`)
  writeManifest(fresh)
  return fresh
}

export function writeManifest(m: Manifest) {
  m.status.last_update = new Date().toISOString()
  writeJSON(`shoots/${m.shoot_id}/index.json`, m, { ensureDir: true })
}

export function bumpCounters(shootId: string, delta: { captioned?: number, errors?: number, total?: number }) {
  const m = loadManifest(shootId)
  if (typeof delta.captioned === 'number') m.status.captioned += delta.captioned
  if (typeof delta.errors === 'number') m.status.errors += delta.errors
  if (typeof delta.total === 'number') m.status.total += delta.total
  writeManifest(m)
  return m
}
