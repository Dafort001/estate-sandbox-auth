import fs from 'node:fs'
import path from 'node:path'
import { r2Path, exists, writeText } from './storage'

type Sections = {
  overview: string
  features: string[]
  light_orientation: string
  materials: string[]
  style_impression: string
  limitations: string
}

type CaptionFile = {
  filename: string
  room_type: string
  sections: Sections
  alt_text_de?: string
  expose_de?: string
}

const ORDER = ['wohnzimmer','wohnkueche','kueche','esszimmer','schlafzimmer','masterbedroom','kinderzimmer','gaestezimmer','arbeitszimmer','flur','bad','gaestebad','hauswirtschaftsraum','abstellraum','technikraum','keller','dachboden','balkon','terrasse','garten','aussen']

export function buildExposeMarkdown(shootId: string) {
  const dir = r2Path(`shoots/${shootId}/captions/json`)
  if (!exists(`shoots/${shootId}/captions/json`)) return '# Exposé\n\n*Keine Daten gefunden.*'

  const files = fs.readdirSync(dir).filter(f => f.endsWith('.json'))
  const entries: CaptionFile[] = files.map(f => JSON.parse(fs.readFileSync(path.join(dir, f), 'utf-8')))

  // Sort by preferred room order
  entries.sort((a,b) => ORDER.indexOf(a.room_type) - ORDER.indexOf(b.room_type))

  const lines: string[] = []
  lines.push(`# Exposé – Objekt ${shootId}`)
  lines.push('')

  // Intro (Wohnzimmer / Wohnküche)
  const intro = entries.find(e => ['wohnzimmer','wohnkueche'].includes(e.room_type))
  if (intro) {
    lines.push(intro.sections.overview)
    lines.push('')
  }

  // Raumabschnitte
  for (const e of entries) {
    lines.push(`## ${e.room_type}`)
    if (e.sections.overview) lines.push(e.sections.overview)
    const feats = e.sections.features?.slice(0,6).join(', ')
    const mats = e.sections.materials?.slice(0,6).join(', ')
    if (feats) lines.push(`**Merkmale:** ${feats}.`)
    if (mats) lines.push(`**Materialien:** ${mats}.`)
    if (e.sections.light_orientation) lines.push(`**Licht:** ${e.sections.light_orientation}.`)
    if (e.sections.style_impression) lines.push(e.sections.style_impression)
    lines.push('')
  }

  const out = lines.join('\n')
  writeText(`shoots/${shootId}/expose/expose_full.md`, out, { ensureDir: true })
  return out
}
