import fs from 'node:fs'
import path from 'node:path'

export type WriteOptions = { ensureDir?: boolean }

const ROOT = process.env.STORAGE_ROOT || 'storage' // simulate R2 in local FS

export function fsPath(p: string) {
  return path.resolve(ROOT, p.replace(/^\/+/, ''))
}

export function ensureDirSync(dir: string) {
  const full = fsPath(dir)
  fs.mkdirSync(full, { recursive: true })
  return full
}

export function writeText(p: string, content: string, opt: WriteOptions = {}) {
  const full = fsPath(p)
  if (opt.ensureDir) fs.mkdirSync(path.dirname(full), { recursive: true })
  fs.writeFileSync(full, content, 'utf-8')
  return full
}

export function writeJSON(p: string, obj: any, opt: WriteOptions = {}) {
  return writeText(p, JSON.stringify(obj, null, 2), opt)
}

export function readJSON<T=any>(p: string): T | null {
  const full = fsPath(p)
  if (!fs.existsSync(full)) return null
  return JSON.parse(fs.readFileSync(full, 'utf-8')) as T
}

export function exists(p: string) {
  return fs.existsSync(fsPath(p))
}

export function listPrefix(prefix: string): string[] {
  const full = fsPath(prefix)
  if (!fs.existsSync(full)) return []
  const out: string[] = []
  const walk = (dir: string, relBase: string) => {
    for (const f of fs.readdirSync(dir)) {
      const fullPath = path.join(dir, f)
      const rel = path.join(relBase, f)
      const stat = fs.statSync(fullPath)
      if (stat.isDirectory()) walk(fullPath, rel)
      else out.push(path.posix.join(prefix, rel).replace(/\\/g,'/'))
    }
  }
  walk(full, '')
  return out
}

export function getObject(p: string): Buffer | null {
  const full = fsPath(p)
  if (!fs.existsSync(full)) return null
  return fs.readFileSync(full)
}
